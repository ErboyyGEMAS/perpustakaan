</div>
<footer class="text-center text-lg-start mt-5 py-4" style="background-color: #343a40; color: #f8f9fa; border-top: 3px solid #007bff;">
    <div class="container">
        <p class="mb-0 d-flex align-items-center justify-content-center">
            &copy; <?php echo date("Y"); ?> Sistem Perpustakaan Sederhana. Dibuat dengan
            <span style="color: #dc3545; margin: 0 5px; font-size: 1.2em;">&hearts;</span> untuk Praktek.
        </p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="../js/script.js"></script>
</body>

</html>